import React from 'react'
import FormLogin from './components/organims/FormLogin'

function App() {
  return (
    <>
      <FormLogin/>
    </>
  )
}

export default App